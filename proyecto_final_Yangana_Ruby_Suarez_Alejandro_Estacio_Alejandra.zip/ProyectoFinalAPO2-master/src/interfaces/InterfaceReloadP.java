package interfaces;

public interface InterfaceReloadP {

	public void reloadP();
	
}
