package interfaces;

public interface InterfaceFire {

	public void fire();
	
}
